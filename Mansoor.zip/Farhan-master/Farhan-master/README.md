# ⊱⋕⊰ FARHAN ⊱⋕⊰

pkg update

pkg upgrade

pkg install python2 

pkg install git 

git clone https://github.com/Tech-abm/Farhan

cd Farhan

pip2 install requests 

pip2 install mechanize 

chmod +x *

python2 abm.py

#USENAME = farhan

#PASSWORD = farhan
